export class CreateAttachmentDto {}
