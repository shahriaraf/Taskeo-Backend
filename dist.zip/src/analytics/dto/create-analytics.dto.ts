export class CreateAnalyticsDto {}
